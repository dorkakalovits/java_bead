package snake.util;

public enum Direction{
	UP,
	DOWN,
	RIGHT,
	LEFT;
}