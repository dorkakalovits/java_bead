package snake.exception;

public class InvalidIndexException extends RuntimeException{
	
}