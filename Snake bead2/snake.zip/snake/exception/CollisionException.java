package snake.exception;

public class CollisionException extends Exception{
	
}